# Shop posters — print notes

Twelve posters, all **11 × 17 (tabloid)**. Ten portrait, two landscape
(`3d-printer-levels` and `seven-pathways`).

## For the graphics shop

- **Size:** 11 × 17, no bleed needed — everything sits inside a 0.75" margin,
  so trimming is forgiving.
- **Colour:** worth printing in colour. The colours carry meaning: green is
  "go", blue is information, orange is a warning, purple is the shop. They still
  read in greyscale, but the warnings stop shouting.
- **Paper:** anything. If a poster is going next to a machine — the laser, the
  J55, the bench — lamination is worth it, because those are the ones that get
  touched with dirty hands and consulted in a hurry.
- Fonts are embedded. Nothing to install.

## Where each one goes

| Poster | Hang it |
|---|---|
| `emergency` | By the door AND by the eyewash. This is the one that matters at the worst moment. |
| `primary-rules` | At the Makerspace door. Conditions of entry. |
| `ppe-dress-right` | At the door, next to the primary rules. |
| `trained-and-authorized` | Where students queue for machine time. |
| `3d-printer-levels` | On the wall by the printers. *(landscape)* |
| `laser` | On or beside the laser. |
| `resin-j55` | At the J55 and at the support-removal station. |
| `cobots` | At the UR cell. |
| `soldering-hot-glue` | Over the electronics bench. |
| `clean-up` | By the sink, or wherever the brooms live. |
| `seven-pathways` | Classroom wall, where juniors can browse it. *(landscape)* |
| `roles-of-an-engineer` | Classroom wall, near where the Full Scope Project runs. |

## Where the content came from

Nothing here is invented. Every fact traces to something already verified in
this project:

- **Primary Makerspace Rules** and **BHR Engineering Makerspace Rules** — your
  two documents, quoted.
- **Machine posters** — the manufacturer manuals and standards behind the
  equipment safety checks: Epilog's FusionPro manual, the Stratasys SUP710
  safety data sheet, Universal Robots' user manual and ISO 10218, LBNL and UNC
  soldering guidance.
- **Roles of an Engineer** — your Full Scope Project brief.
- **Pathways** — the seven hub guides.

If a rule changes, change it in the source and re-run `make_posters.py`; the
posters and the website read from the same data.

## Deliberately not printed yet

- **Grading breakdown.** The Software hub guide says 40/30/20/10 and the live
  grading document says 35/30/15/20. Printing the wrong one on a wall is worse
  than not printing it. Tell me which is right and it takes two minutes.
- **Classroom rules.** Same reason — worth confirming the current set before it
  goes up in poster form.
- **A "find it on the hub" poster with a QR code.** Waiting on the site having
  a real URL.
